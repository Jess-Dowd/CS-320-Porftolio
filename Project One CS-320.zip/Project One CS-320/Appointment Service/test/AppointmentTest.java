import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {

        Calendar futureDate = Calendar.getInstance();
        futureDate.add(Calendar.DATE, 2); // 2 days in the future

        Appointment appt = new Appointment("123", futureDate.getTime(), "Doctor visit");
        assertEquals("123", appt.getAppointmentId());
        assertEquals("Doctor visit", appt.getDescription());

    }

    @Test
    public void testInvalidAppointmentId() {
        Calendar futureDate = Calendar.getInstance();
        futureDate.add(Calendar.DATE, 2);

        // ID is null or too long
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate.getTime(), "Meeting"));
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("12345678901", futureDate.getTime(), "Meeting"));

    }

    @Test
    public void testPastDate() {
        Calendar pastDate = Calendar.getInstance();
        pastDate.add(Calendar.DATE, -1); // Set to a past date

        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("123", pastDate.getTime(), "Expired appointment"));
    }

    @Test
    public void testDescriptionTooLong() {

        Calendar futureDate = Calendar.getInstance();
        futureDate.add(Calendar.DATE, 2);

        // Description longer than 50 characters

        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("123", futureDate.getTime(), "A".repeat(51)));
    }
}
