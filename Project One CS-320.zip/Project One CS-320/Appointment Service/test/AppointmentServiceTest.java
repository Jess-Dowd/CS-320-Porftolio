import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Calendar futureDate = Calendar.getInstance();
        futureDate.add(Calendar.DATE, 2);

        // Create a new appointment and add it
        Appointment appt = new Appointment("123", futureDate.getTime(), "Check-up");
        service.addAppointment(appt);

        // Check if the appointment exists in the service
        assertEquals(appt, service.getAppointment("123"));
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Calendar futureDate = Calendar.getInstance();
        futureDate.add(Calendar.DATE, 2);

        Appointment appt = new Appointment("123", futureDate.getTime(), "Meeting");
        service.addAppointment(appt);

        // Delete the appointment

        service.deleteAppointment("123");

        // amke sure the appointment is removed

        assertNull(service.getAppointment("123"));
    }

    @Test
    public void testAddDuplicateAppointment() {

        AppointmentService service = new AppointmentService();
        Calendar futureDate = Calendar.getInstance();
        futureDate.add(Calendar.DATE, 2);

        Appointment appt1 = new Appointment("123", futureDate.getTime(), "First appointment");
        Appointment appt2 = new Appointment("123", futureDate.getTime(), "Second appointment");

        service.addAppointment(appt1);

        // Adding another appointment with the same ID should fail
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appt2));

    }

    @Test
    public void testDeleteNonexistentAppointment() {
        AppointmentService service = new AppointmentService();

        // Trying to delete an appointment that doesn’t exist should fail
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("notexist"));
    }
}
