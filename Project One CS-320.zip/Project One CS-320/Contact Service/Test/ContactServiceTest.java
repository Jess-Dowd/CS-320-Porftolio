import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

// Test class for ContactService
public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    public void setup() {
        service = new ContactService(); // Creating a new service before each test
    }

    @Test
    public void testAddContact() {
        // Adding a contact and making sure it gets stored
        Contact contact = new Contact("1234567890", "Jess", "Dowd", "1234567890", "123 Abc Street");
        service.addContact(contact);
        assertEquals(contact, service.getContact("1234567890"));
    }

    @Test
    public void testDeleteContact() {
        // Adding and then deleting a contact to make sure it's gone
        Contact contact = new Contact("1234567890", "Jess", "Dowd", "1234567890", "123 Abc Street");
        service.addContact(contact);
        service.deleteContact("1234567890");
        assertNull(service.getContact("1234567890"));
    }

    @Test
    public void testUpdateContact() {
        // Adding a contact, then updating their info, then checking if the update worked
        Contact contact = new Contact("1234567890", "Jess", "Dowd", "1234567890", "123 Abc Street");
        service.addContact(contact);
        service.updateContact("1234567890", "Jane", "Smith", "0987654321", "456 Oak Street");
        Contact updated = service.getContact("1234567890");
        assertEquals("Jane", updated.getFirstName());
        assertEquals("Smith", updated.getLastName());
        assertEquals("0987654321", updated.getPhone());
        assertEquals("456 Oak Street", updated.getAddress());
    }
}
