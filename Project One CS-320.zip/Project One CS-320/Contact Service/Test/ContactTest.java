import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

// Test class for the Contact class
public class ContactTest {

    @Test
    public void testContactCreation() {
        // Created a contact and check if all values are stored correctly
        Contact contact = new Contact("1234567890", "Jess", "Dowd", "1234567890", "123 Abc Street");
        assertEquals("1234567890", contact.getContactId());
        assertEquals("Jess", contact.getFirstName());
        assertEquals("Dowd", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Abc Street", contact.getAddress());
    }

    @Test
    public void testInvalidContactCreation() {
        // Trying to create a contact with a null ID (should throw an exception)
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Jess", "Dowd", "1234567890", "123 Abc Street");
        });
    }
}
