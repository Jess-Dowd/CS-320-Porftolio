import java.util.HashMap;
import java.util.Map;

// ContactService class manages all contacts (adding, updating, deleting)
public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>(); // Stores the contacts with their unique ID

    // Adds a new contact and makes sure the ID is unique
    public void addContact(Contact contact) {

        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }

        contacts.put(contact.getContactId(), contact);
    }

    // Deletes a contact by its ID
    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    // Updates a contact (only the first name, last name, phone, and address can change)
    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        Contact contact = contacts.get(contactId);
        if (contact != null) {
            contact.setFirstName(firstName);
            contact.setLastName(lastName);
            contact.setPhone(phone);
            contact.setAddress(address);
        }

    }

    // Gets a contact by its ID
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}
