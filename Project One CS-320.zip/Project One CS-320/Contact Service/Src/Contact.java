// Contact class has all the details for a contact
public class Contact {
    private final String contactId; // Unique ID and can't be changed after its creation
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    // Constructor to make sure all fields follow the rules
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {

        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Contact ID must be non-null and 10 characters max.");
        }

        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("First name must be non-null and 10 characters max.");
        }

        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Last name must be non-null and 10 characters max.");
        }

        if (phone == null || phone.length() != 10 || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone number must be exactly 10 numbers.");
        }

        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Address must be non-null and 30 characters max.");
        }

        this.contactId = contactId;

        this.firstName = firstName;

        this.lastName = lastName;

        this.phone = phone;

        this.address = address;
    }

    // Getters to return all the values of each field

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    // Setters for updating fields (except contactId since that cant be changed)

    public void setFirstName(String firstName) {

        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }

        this.firstName = firstName;
    }

    public void setLastName(String lastName) {

        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }

        this.lastName = lastName;
    }

    public void setPhone(String phone) {

        if (phone == null || phone.length() != 10 || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Invalid phone number");
        }

        this.phone = phone;
    }

    public void setAddress(String address) {

        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }

        this.address = address;
    }

}
