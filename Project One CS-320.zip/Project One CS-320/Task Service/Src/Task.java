public class Task {
    private final String taskId; // Task ID is unique and can't be changed
    private String name; // Task name, must be within character limit
    private String description; // Task description, must be within character limit

    // Constructor to create a new task
    public Task(String taskId, String name, String description) {

        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Error: Task ID must not be null and should be 10 characters max.");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Error: Task name must not be null and should be 20 characters max.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException(
                    "Error: Task description must not be null and should be 50 characters max.");

        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Getter for task ID (unchangeable)
    public String getTaskId() {
        return taskId;
    }

    // Getter for task name
    public String getName() {
        return name;

    }

    // Setter for task name (ensures it follows rules)
    public void setName(String name) {

        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Error: Task name must not be null and should be 20 characters max.");
        }
        this.name = name;

    }

    // Getter for task description
    public String getDescription() {

        return description;

    }

    // Setter for task description (ensures it follows rules)
    public void setDescription(String description) {

        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException(
                    "Error: Task description must not be null and should be 50 characters max.");
        }
        this.description = description;

    }
}
