import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>(); // Store tasks in memory
    private static final Logger logger = Logger.getLogger(TaskService.class.getName()); // Logger for tracking actions

    // Add a task to the service
    public void addTask(Task task) {

        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException(
                    "Error: Task ID must be unique. Task with ID " + task.getTaskId() + " already exists.");
        }
        tasks.put(task.getTaskId(), task);
        logger.info("Task added successfully: " + task.getTaskId());

    }

    // Delete a task using its ID
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException(
                    "Error: Task with ID " + taskId + " does not exist, so it can't be deleted.");
        }
        tasks.remove(taskId);
        logger.info("Task deleted successfully: " + taskId);

    }

    // Update the task name
    public void updateTaskName(String taskId, String newName) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Error: Cannot update. Task with ID " + taskId + " not found.");
        }
        tasks.get(taskId).setName(newName);
        logger.info("Task name updated successfully for ID: " + taskId);
    }

    // Update the task description
    public void updateTaskDescription(String taskId, String newDescription) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Error: Cannot update. Task with ID " + taskId + " not found.");
        }
        tasks.get(taskId).setDescription(newDescription);
        logger.info("Task description updated successfully for ID: " + taskId);

    }

    // Retrieve a task by ID
    public Task getTask(String taskId) {
        return tasks.get(taskId);

    }
}
