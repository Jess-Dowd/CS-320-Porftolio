import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("12345", "Task Name", "Task Description");
        taskService.addTask(task);

        assertEquals(task, taskService.getTask("12345"));
    }

    @Test
    public void testAddDuplicateTask() {

        Task task1 = new Task("12345", "Task Name", "Task Description");
        Task task2 = new Task("12345", "Another Name", "Another Description");

        taskService.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task2));

    }

    @Test
    public void testDeleteTask() {

        Task task = new Task("12345", "Task Name", "Task Description");
        taskService.addTask(task);
        taskService.deleteTask("12345");

        assertNull(taskService.getTask("12345"));

    }

    @Test
    public void testDeleteNonexistentTask() {

        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("99999"));

    }

    @Test
    public void testUpdateTaskName() {

        Task task = new Task("12345", "Task Name", "Task Description");
        taskService.addTask(task);
        taskService.updateTaskName("12345", "New Name");

        assertEquals("New Name", taskService.getTask("12345").getName());

    }

    @Test
    public void testUpdateTaskDescription() {

        Task task = new Task("12345", "Task Name", "Task Description");
        taskService.addTask(task);
        taskService.updateTaskDescription("12345", "New Description");

        assertEquals("New Description", taskService.getTask("12345").getDescription());

    }

    @Test
    public void testUpdateNonexistentTask() {

        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("99999", "New Name"));
        assertThrows(IllegalArgumentException.class,
                () -> taskService.updateTaskDescription("99999", "New Description"));

    }
}
